const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/user");

exports.user_signup = (req, res, next) => {
	console.log("USER CONTROLLER")
	console.log(req.body)
	User.find({ email: req.body.email })
		.exec()
		.then(user => {
		if (user.length >= 1) {
			return res.status(409).json({
			message: "Mail exists"
			});
		} else {
			bcrypt.hash(req.body.password, 10, (err, hash) => {
				if (err) {
					return res.status(500).json({
					error: err
					});
				} else {
				const user = new User({
					_id: new mongoose.Types.ObjectId(),
					email: req.body.email,
					name: req.body.name,
					avatar: req.body.avatar,
					password: hash
				});
				console.log(hash)
				user
					.save()
					.then(result => {
						console.log(result);
						res.status(201).json({
							id: user.id,
							message: "User created"
						});
					})
					.catch(err => {
						console.log(err);
						res.status(500).json({
						error: err
						});
					});
				}
			});
		}
    });
};

exports.user_update = (req, res, next) => {
	User.findByIdAndUpdate({ _id: req.body.id })
	.exec()
	.then(user => {
		console.log("USER FOUND: ")
		user.set({'name': req.body.name})
		user.set({'email': req.body.email})
		user.save()
		.then(result => {
			res.status(200).send({
				message: "USER UPDATED",
				user: user 
			});
		}).catch(err => {
			res.status(500).json({
				error: err
			})
		})
	});
};

exports.user_updateav = (req, res, next) => {
	User.findByIdAndUpdate({ _id: req.body.id })
	.exec()
	.then(user => {
		console.log("USER FOUND: ")
		user.set({'avatar': req.body.avatar})
		user.save()
		.then(result => {
			res.status(200).send({
				message: "USER AVATAR UPDATED",
				user: user 
			});
		}).catch(err => {
			res.status(500).json({
				error: err
			})
		})
	});
};

exports.user_login = (req, res, next) => {
	User.find({ email: req.body.email })
		.exec()
		.then(user => {
		let id = user._id
		if (user.length < 1) {
			return res.status(401).json({
			message: "Auth failed, muchacho"
			});
		}
		bcrypt.compare(req.body.password, user[0].password, (err, result) => {
		if (err) {
			return res.status(401).json({
			message: "Auth failed, hombre"
			});
		}
		if (result) {
			const token = jwt.sign(
			{
				email: user.email,
				userId: user._id,
			},
				'secret_this_should_be_longer',
			{
				expiresIn: 3600
			}
			);
			return res.status(200).json({
				user: user[0],
				token: token,
				
			});
		}
        res.status(401).json({
			message: "Auth failed"
			});
		});
    })
    .catch(err => {
      console.log(err);
      res.status(500).json({
        error: err
      });
    });
};

exports.user_delete = (req, res, next) => {
	User.remove({ _id: req.params.userId })
		.exec()
		.then(result => {
			res.status(200).json({
				message: "User deleted"
			});
		})
		.catch(err => {
			console.log(err);
			res.status(500).json({
				error: err
			});
		});
}; 